<div class="popup">         <div class="content event"><div class="clearfix" id="info_window">
    <div class="image">
        <img src="css/preview_7oldfulton.jpg?" class="preview" alt="Preview_7oldfulton">
    </div>
    <br>
    <div class="column_1">
        
        
        <a class="itinerary_link" href="#">Add to itinerary</a>
        <h3>Location</h3>
            <div>
                7 Old Fulton Street
                
            </div>
            <a target="_new" href="http://maps.google.com/maps?saddr=&amp;daddr=40.7027,-73.9937">View on Map</a>
            <h3>Hours</h3>
            Mon-Sun: 11am-11pm
            <h3>Contact</h3>
            <div>(718) 797-0007</div>
            <a target="_new" href="http://www.7oldfulton.com">Website</a>
        
            <h3>Cuisine</h3><div>Italian</div>
            
    </div>
    <div class="column_2">
        <h2>7 Old Fulton</h2>
        <p>7 Old Fulton, located under the Brooklyn Bridge, offers a selection of international cuisine: everything from Italian (Veal Tuscany) to French (Shrimp Saint-Tropez) to Spanish (Chicken Barcelona) and classic "American" cuisine like their Cowboy Steak. </p>
        
    </div>
</div></div>         <a class="close" href="#"><img title="close" class="close_image" src="css/closelabel.png"></a>       </div>